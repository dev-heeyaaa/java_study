package chapter10;

import javax.swing.text.ChangedCharSetException;

public class Ex7 {
 
	public static void main(String[] args) {
		Ex7 ex7 = new Ex7();
		int num1 = 10;
		
		System.out.println("before : " + num1);
		ex7.change(num1);
		System.out.println("after : "+num1);
		System.out.println();
		
		SimpleType1 type = new SimpleType1();
		type.num1 = 10;
		
		System.out.println("before : " + type.num1);
		ex7.change(type);
		System.out.println("after : "+type.num1);

		
		
	}
	
	void change(int num1) {
		num1 = num1 * 10;
		
		System.out.println("change(int) : " + num1);
		
	}
	void change(SimpleType1 type) {
		type.num1 = type.num1*10;
		
		System.out.println("change(SimpleType1) : " + type.num1);
	}

}
