package chaper5;

public class Ex4 {

	public static void main(String[] args) {
		short a = 32_767;
		short b = 1;
		
		int c = a + b;
		System.out.println(c);
	}

}
