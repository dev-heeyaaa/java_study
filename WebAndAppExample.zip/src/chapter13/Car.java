package chapter13;

public class Car {
	private String color;
	private int door;
	
	public void drive() {
		System.out.println("Drive, Brrr~~~~~~~");
	}
	
	public void stop() {
		System.out.println("stop!!!");
	}
}
