package chapter10;

public class Ex10 {

	double div(int var1, int var2) {
		double result = var1 % (double)var2;
		return result;
	}
	
	int stackAdd(int inp) {
		int sum = 0;
		for (int i = 1; i <= inp; i++) {
			sum = sum + i;
		}
		return sum;
	}
	public static void main(String[] args) {
		
		Ex10 ex10 = new Ex10();
		
	
		
		System.out.println(ex10.div(36, 5));
		System.out.println(ex10.stackAdd(5));

	}

}
