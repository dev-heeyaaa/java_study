package chapter11;

public class Ex3 {

	public static void main(String[] args) {
		TourGuide tourGuide = new TourGuide("korean");
		
		tourGuide.doLeisureSports();
		tourGuide.doSightseeing();
		tourGuide.eatFood();
	}

}
