package chaper5;

public class Ex7 {

	public static void main(String[] args) {
		char ch = '3';
		boolean result = 48 <= ch && ch <= 57;
		
		System.out.println(result);

	}

}
