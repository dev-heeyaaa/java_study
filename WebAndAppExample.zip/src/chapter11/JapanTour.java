package chapter11;

public class JapanTour extends Providable {

}
