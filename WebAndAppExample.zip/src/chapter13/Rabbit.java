package chapter13;

public class Rabbit extends Animal {
	public String getMyname() {
		return "rabbit";
	}
}
