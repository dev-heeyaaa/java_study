package chapter10;

public class Ex6 {
	void example1() {
		System.out.println(10 + 20);
	}
	void example2(int n1, int n2) {
		System.out.println(n1+n2);
	}
	
	void example3(int n3, int n4) {
		if(n3 > n4) {
			System.out.println(n3);
		}else {
			System.out.println(n4);
		}
	}
	
	void example4(int var1, int var2) {
		if(var1 < var2) {
			System.out.println(var2);
		}
		else {
			System.out.println(var1);
		}
	}
	public static void main(String[] args) {
		Ex6 ex6 = new Ex6();
		
		ex6.example1();
		ex6.example2(5, 10);
		ex6.example3(10, 15);
		ex6.example4(10, 11);
	}

}
