package chaper5;

public class Numbers {
	int num1;
	int num2;
	
}
