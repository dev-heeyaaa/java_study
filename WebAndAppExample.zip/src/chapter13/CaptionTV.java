package chapter13;

public class CaptionTV extends TV {
	private String text;
	
	public void caption() {
		System.out.println(text);
	}
}
