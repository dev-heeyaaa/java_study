package chapter13;

public class Vegetable extends Product{

}
