package chapter13;

public class Child2 extends Parent2{
	
}
