package chapter10;

public class Ex9 {
	int add() {
		int result = 1+1;
		return result;
	}
public static void main(String[] args) {
	Ex9 ex9 = new Ex9();
	
	int result = ex9.add();
	 
}

}
