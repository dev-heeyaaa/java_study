package chapter10;

import java.util.Scanner;

public class Ex5 {
	void gugudan(int n1) {
		for (int i = 1; i < 10; i++) {
			System.out.println(n1+" * "+i+" = "+n1 * i);

		}System.out.println();
	}
	
	public static void main(String[] args) {
		Scanner scanf = new Scanner(System.in);
		System.out.print("����� ������(2~9) :");
		
		int input = scanf.nextInt();

		Ex5 ex5 = new Ex5();
		ex5.gugudan(input);



	}

}
