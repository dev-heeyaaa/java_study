package chapter13;

public class Lion extends Animal {
	public String getMyname() {
		return "lion";
	}
}


