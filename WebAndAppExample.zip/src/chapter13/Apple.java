package chapter13;

public class Apple extends Fruit{
	
	
}
