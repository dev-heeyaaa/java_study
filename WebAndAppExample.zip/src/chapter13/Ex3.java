package chapter13;

public class Ex3 {

	public static void main(String[] args) {
		Car car = null;
		FireEngine fe1 = new FireEngine();
		FireEngine fe2 = null;
		
		// ��ĳ����
		car = (Car) fe1;
		// �ٿ�ĳ���� 
		fe2 = (FireEngine) car;
		
		
		fe1.water();
		fe2.water();
		
		Car car1 = new Car();
		FireEngine fe = new FireEngine();
		System.out.println(fe instanceof FireEngine);
		System.out.println(fe instanceof Car);
		System.out.println(fe instanceof Object);
		System.out.println("=== ===");
		System.out.println(car1 instanceof FireEngine);
		System.out.println(car1 instanceof Car);
		System.out.println(car1 instanceof Object);
		
		
	}

}
