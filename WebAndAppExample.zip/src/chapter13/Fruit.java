package chapter13;

public class Fruit extends Product{

}
