package chapter11;

public interface A {

}
