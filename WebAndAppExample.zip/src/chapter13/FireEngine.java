package chapter13;

public class FireEngine extends Car{
	public void water() {
		System.out.println("Water~~~~~~~~");
	}
}
