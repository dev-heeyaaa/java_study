package chapter10;

public class SimpleType1 {
	int num1;
	
}
