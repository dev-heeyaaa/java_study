package chapter10;

public class Ex11 {
	int add(int num1, int num2) {
		int result = num1 + num2;
		
		return result;
	}
	
	double div(int n1, int n2) {
		double result = n1 % (double)n2;
		return result;
	}
	
	int stackAdd(int inp) {
		int sum = 0;
		for (int i = 1; i <= inp; i++) {
			sum = sum + i;
		}
		return sum;
	}
	public static void main(String[] args) {
	
		Ex11 ex11 = new Ex11();
		
		int result = ex11.add(1, 1);
		System.out.println(result);
		
		
		double result1 = ex11.div(37, 7);
		System.out.println(result1);
		
		int result2 = ex11.stackAdd(10);
		System.out.println(result2);

		
				
	}

}
