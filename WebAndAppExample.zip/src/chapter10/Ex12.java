package chapter10;

public class Ex12 {
	// �����ε��� �޼���
	int add(int n1, int n2) {
		int result = n1 + n2;
		return result;
	}
	
	double add(double n1, double n2) {
		double result = n1 + n2;
		return result;
	}
	
	double add(int n1, double n2) {
		double result = n1 + n2;
		return result;
	}
	
	public static void main(String[] args) {
		Ex12 ex12 = new Ex12();
		int result1 = ex12.add(3, 5);
		double result2 = ex12.add(3.14, 2.5);
		double result3 = ex12.add(15, 3.14);
		
		System.out.println(result1);
		System.out.println(result2);
		System.out.println(result3);
	}

}
