package chapter10;

public class Ex3 {

	void simple4() {
		System.out.println("2021-03-14");
	}
	public static void main(String[] args) {

		Ex3 ex3 = new Ex3();
		
		ex3.simple4();
	}

}
