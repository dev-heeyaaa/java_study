package chapter10;

public class Ex2 {

	void simple2() {
		System.out.println("Java Program Strart!");
	}
	
	void simple3() {
		System.out.println(1+1);
	}
	public static void main(String[] args) {
		Ex2 ex2 = new Ex2();
		ex2.simple2();
		ex2.simple3();

	}

}
