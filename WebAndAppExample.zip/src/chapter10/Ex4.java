package chapter10;

public class Ex4 {
	void simple1(int val) {
		int result = val +1 ;
		System.out.println(result);
	}

	void simple2() {
		System.out.println("Hello World~!");
	}
	void simple3(String message) {
		System.out.println(message);
	}

	// simple4 �޼���� ���� �� ���� �ʿ��� �޼���
	void simple4(int num1, int num2) {
		if(num1 > num2) {
			System.out.println(num1);
		}else {
			System.out.println(num2);
		}
	}

	void simple5(int n1, int n2, char monja) {
		if(monja == '+') {
			System.out.println(n1 + n2);
		}else if(monja == '-') {
			System.out.println(n1-n2);
		}
	}
	public static void main(String[] args) {
		Ex4 ex4 = new Ex4();
		ex4.simple1(10);

		ex4.simple2();
		ex4.simple3("�ȳ� ����");
		ex4.simple3("���� ���� �ʹ�");
		ex4.simple4(6, 10);
		ex4.simple5(10, 6, '-');
	}

}
