package project4;

public enum Menu {
	empty, insert, update, delete, list, exit
}
