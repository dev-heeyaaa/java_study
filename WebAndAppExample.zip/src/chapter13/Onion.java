package chapter13;

public class Onion extends Vegetable{

}
