package chapter13;

public class Banana extends Fruit{

}
