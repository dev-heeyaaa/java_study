package chapter13;

public class Monkey extends Animal{
	public String getMyname() {
		return "monkey";
	}
}
